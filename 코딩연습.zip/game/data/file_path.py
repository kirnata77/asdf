# =====================
# 파일 경로 레지스트리
# =====================
# 프로젝트의 모든 .py 모듈이 실제로 어느 패키지 경로에 있는지 기록해둔
# 참고용 딕셔너리다. 새 파일을 추가하면 이 목록에도 항목을 추가한다.
#
# import 문을 쓸 때는 여기 적힌 dotted 경로를 그대로 쓰면 된다.
# 예) skill_system.py에서 buff.py를 쓰려면
#     from game.data.buff import buff
# 처럼, 이 딕셔너리 값에서 마지막 조각(모듈명)을 뺀 나머지를 "from" 뒤에,
# 마지막 조각(모듈명)을 "import" 뒤에 쓰면 된다.
#
# 키: 파일명 (확장자 제외)
# 값: 전체 dotted 경로 (game.으로 시작, 모듈명까지 포함)
#
# 주의: 이 딕셔너리는 .py 모듈의 import 경로만 관리한다. 폰트/이미지
# 같은 비-코드 리소스 파일의 위치는 맨 아래 "에셋 파일 위치" 절 참고.

파일경로 = {
    # game/data/ 최상위
    "file_path": "game.data.file_path",

    # game/data/job_skill/
    "job_skill_010m_ghost_swordsman": "game.data.job_skill.job_skill_010m_ghost_swordsman",
    "job_skill_011m_weapon_master": "game.data.job_skill.job_skill_011m_weapon_master",
    "job_skill_020f_fighter": "game.data.job_skill.job_skill_020f_fighter",
    "job_skill_030f_gunner": "game.data.job_skill.job_skill_030f_gunner",
    "job_skill_022f_striker": "game.data.job_skill.job_skill_022f_striker",
    "job_skill_031f_ranger": "game.data.job_skill.job_skill_031f_ranger",
    "job_skill_040f_mage": "game.data.job_skill.job_skill_040f_mage",
    "job_skill_041f_elemental_master": "game.data.job_skill.job_skill_041f_elemental_master",
    "job_skill_050f_priest": "game.data.job_skill.job_skill_050f_priest",
    "job_skill_051f_crusader": "game.data.job_skill.job_skill_051f_crusader",
    "job_skill_format": "game.data.job_skill.job_skill_format",
    "job_skill_0000": "game.data.job_skill.job_skill_0000",

    # game/data/job_level/
    "job_level_010m_ghost_swordsman": "game.data.job_level.job_level_010m_ghost_swordsman",
    "job_level_011m_weapon_master": "game.data.job_level.job_level_011m_weapon_master",
    "job_level_020f_fighter": "game.data.job_level.job_level_020f_fighter",
    "job_level_022f_striker": "game.data.job_level.job_level_022f_striker",
    "job_level_030f_gunner": "game.data.job_level.job_level_030f_gunner",
    "job_level_031f_ranger": "game.data.job_level.job_level_031f_ranger",
    "job_level_040f_mage": "game.data.job_level.job_level_040f_mage",
    "job_level_041f_elemental_master": "game.data.job_level.job_level_041f_elemental_master",
    "job_level_050f_priest": "game.data.job_level.job_level_050f_priest",
    "job_level_051f_crusader": "game.data.job_level.job_level_051f_crusader",
    "job_level_formet": "game.data.job_level.job_level_formet",

    # game/data/perks/
    "perks_class_0000": "game.data.perks.perks_class_0000",
    "perks_class_010m": "game.data.perks.perks_class_010m",
    "perks_class_020f": "game.data.perks.perks_class_020f",
    "perks_class_030f": "game.data.perks.perks_class_030f",
    "perks_class_040f": "game.data.perks.perks_class_040f",
    "perks_class_050f": "game.data.perks.perks_class_050f",
    "perks_class_format": "game.data.perks.perks_class_format",

    # game/data/buff/
    "buff": "game.data.buff.buff",
    "debuff": "game.data.buff.debuff",
    "skill_effects": "game.data.buff.skill_effects",
    "status_effects": "game.data.buff.status_effects",
    "summon_00": "game.data.buff.summon_00",

    # game/data/ability/
    "job_ability_010m": "game.data.ability.job_ability_010m",
    "job_ability_020f": "game.data.ability.job_ability_020f",
    "job_ability_030f": "game.data.ability.job_ability_030f",
    "job_ability_040f": "game.data.ability.job_ability_040f",
    "job_ability_050f": "game.data.ability.job_ability_050f",
    "job_ability_format": "game.data.ability.job_ability_format",
    "job_ability_0000": "game.data.ability.job_ability_0000",

    # game/data/monster/
    "monster_race_goblin": "game.data.monster.monster_race_goblin",
    "monster_race_tau": "game.data.monster.monster_race_tau",
    "monster_race_lugaru": "game.data.monster.monster_race_lugaru",
    "monster_race_human": "game.data.monster.monster_race_human",
    "monster_race_zombie": "game.data.monster.monster_race_zombie",
    "monster_formet": "game.data.monster.monster_formet",
    "monster_ability": "game.data.monster.monster_ability",
    "monster_title": "game.data.monster.monster_title",
    "monster_drop": "game.data.monster.monster_drop",

    # game/data/equipment/
    "eq_01_weapon_010": "game.data.equipment.eq_01_weapon_010",
    "eq_01_weapon_020": "game.data.equipment.eq_01_weapon_020",
    "eq_01_weapon_formet": "game.data.equipment.eq_01_weapon_formet",
    "eq_01_weapon_030": "game.data.equipment.eq_01_weapon_030",
    "eq_01_weapon_040": "game.data.equipment.eq_01_weapon_040",
    "eq_01_weapon_050": "game.data.equipment.eq_01_weapon_050",
    "eq_03_accesery_08_bracelet": "game.data.equipment.eq_03_accesery_08_bracelet",
    "eq_02_armor_01_top": "game.data.equipment.eq_02_armor_01_top",
    "eq_02_armor_03_shoulder": "game.data.equipment.eq_02_armor_03_shoulder",
    "eq_02_armor_04_belt": "game.data.equipment.eq_02_armor_04_belt",
    "eq_02_armor_formet": "game.data.equipment.eq_02_armor_formet",
    "eq_02_armor_set": "game.data.equipment.eq_02_armor_set",
    "eq_02_armor_05_shoes": "game.data.equipment.eq_02_armor_05_shoes",
    "eq_03_accesery_06_necklace": "game.data.equipment.eq_03_accesery_06_necklace",
    "eq_03_accesery_07_ring": "game.data.equipment.eq_03_accesery_07_ring",
    "eq_03_accesery_set": "game.data.equipment.eq_03_accesery_set",
    "eq_04_special_11_earring": "game.data.equipment.eq_04_special_11_earring",
    "eq_04_special_10_magicstone": "game.data.equipment.eq_04_special_10_magicstone",
    "eq_04_special_09_subequipment": "game.data.equipment.eq_04_special_09_subequipment",
    "eq_04_special_set": "game.data.equipment.eq_04_special_set",
    "eq_02_armor_02_bottom": "game.data.equipment.eq_02_armor_02_bottom",

    # game/data/item/
    "item_potion": "game.data.item.item_potion",
    "item_consumable": "game.data.item.item_consumable",
    "item_materials": "game.data.item.item_materials",
    "item_quest": "game.data.item.item_quest",

    # game/data/character/
    "character_formet": "game.data.character.character_formet",
    "player_formet": "game.data.character.player_formet",

    # game/data/MAP/
    "map_formet": "game.data.MAP.map_formet",
    "map_utils": "game.data.MAP.map_utils",
    "map_01A_D01_Lorien": "game.data.MAP.map_01A_D01_Lorien",
    "map_01A_D02_Hollow_Lorien": "game.data.MAP.map_01A_D02_Hollow_Lorien",
    "map_01A_D03_mirkwood": "game.data.MAP.map_01A_D03_mirkwood",
    "map_01A_D04_Hollow_mirkwood": "game.data.MAP.map_01A_D04_Hollow_mirkwood",
    "map_01A_D05_thunderland": "game.data.MAP.map_01A_D05_thunderland",
    "map_01A_D06_poison_thunderland": "game.data.MAP.map_01A_D06_poison_thunderland",
    "map_01A_D07_frost_mirkwood": "game.data.MAP.map_01A_D07_frost_mirkwood",
    "map_01A_D08_grakquarak": "game.data.MAP.map_01A_D08_grakquarak",
    "map_01A_D09_blazing_grakquarak": "game.data.MAP.map_01A_D09_blazing_grakquarak",
    "map_01A_D10_shadow_thunderland": "game.data.MAP.map_01A_D10_shadow_thunderland",

    # game/data/town/
    "town_01A_T01_Elvengard": "game.data.town.town_01A_T01_Elvengard",
    "town_01A_T02_hendonmyre": "game.data.town.town_01A_T02_hendonmyre",
    "town_formet": "game.data.town.town_formet",

    # game/system/
    "main_system": "game.system.main_system",
    "equipment_system": "game.system.equipment_system",
    "dice_utils": "game.system.dice_utils",
    "effect_engine": "game.system.effect_engine",
    "monster_ai": "game.system.monster_ai",
    "map_system": "game.system.map_system",
    "party_system": "game.system.party_system",
    "player_system": "game.system.player_system",
    "save_system": "game.system.save_system",
    "ui_system": "game.system.ui_system",
    "shop_system": "game.system.shop_system",
    "quest_system": "game.system.quest_system",
    "town_system": "game.system.town_system",
    "character_data_system": "game.system.character_data_system",
    "character_creation_system": "game.system.character_creation_system",
    "character_levelup_system": "game.system.character_levelup_system",
    "combat_system": "game.system.combat_system",
    "skill_system": "game.system.skill_system",

    # game/UI/
    "ui_main": "game.UI.ui_main",
    "ui_battle": "game.UI.ui_battle",
    "ui_party": "game.UI.ui_party",
    "ui_party_management": "game.UI.ui_party_management",
    "ui_status": "game.UI.ui_status",
    "ui_skill": "game.UI.ui_skill",
    "ui_town": "game.UI.ui_town",
    "ui_dungeon": "game.UI.ui_dungeon",
    "ui_item": "game.UI.ui_item",
    "ui_fild": "game.UI.ui_fild",
    "ui_character_creation": "game.UI.ui_character_creation",
    "ui_shop": "game.UI.ui_shop",
    "ui_character": "game.UI.ui_character",
    "ui_player": "game.UI.ui_player",

    # game/screens/ (Kivy 화면 - 예전 최상위 screens.py를 6개로 나눔, 2026-09-29)
    "screens_common": "game.screens.screens_common",
    "screens_menu": "game.screens.screens_menu",
    "screens_town": "game.screens.screens_town",
    "screens_dungeon": "game.screens.screens_dungeon",
    "screens_battle": "game.screens.screens_battle",
    "screens_party": "game.screens.screens_party",
}

# =====================
# 참고: 에셋(폰트/이미지 등 비-코드 리소스) 파일 위치
# =====================
# 실제 프로젝트 기준. 최상위 루트는 코딩연습/ 폴더이고, 실행 진입점
# (main.py 등)과 빌드 설정은 루트에, 게임 패키지는 루트 아래 game/에 있다.
# game은 UI/플랫폼과 무관한 순수 로직+데이터 패키지 성격을 유지하되,
# 폰트·이미지처럼 화면 표시에만 쓰이는 리소스는 코드/데이터와 구분해서
# game 바로 아래의 assets/ 폴더에 담는다 (game과 형제가 아니라 game 안에 있음).
# (이 파일들은 .py 모듈이 아니므로 위 파일경로 딕셔너리에는 넣지 않는다)
#
# 코딩연습/
# ├── main.py
# ├── gameflow.py
# ├── buildozer.spec
# └── game/
#     ├── data/            (직업/몬스터/맵 등 게임 콘텐츠 데이터)
#     ├── system/          (전투/스킬 등 로직)
#     ├── UI/              (tkinter 화면 - 지금 실행 흐름에서는 쓰지 않음)
#     ├── screens/         (Kivy 화면 6개 - screens_common/menu/town/
#     │                     dungeon/battle/party.py, main.py가 가져온다)
#     ├── saves/           (세이브 파일)
#     ├── assets/
#     │   ├── font/       NanumGothic-Diet.ttf (다이어트 폰트 1개, 볼드 없음)
#     │   ├── character/  캐릭터 SD 이미지 (asset_sd_character_*.webp)
#     │   ├── dungeon/    던전 타일 이미지 (asset_tile_*.webp)
#     │   │                  asset_tile_grass.webp   풀밭 (8x8)
#     │   │                  asset_tile_dirt.webp    흙길 (8x8)
#     │   │                  asset_tile_forest.webp  숲 (8x8, 아직 미사용)
#     │   │                  asset_tile_tree.webp    나무 (8x16, 세로 2칸)
#     │   │                  asset_tile_gate.webp    게이트 (8x16, 세로 2칸)
#     │   │                  asset_tile_cage.webp    감옥에 갇힌 소녀 (16x16)
#     │   ├── monster/     몬스터 이미지 (asset_monster_*.webp)
#     │   └── town/       마을 배경 그림 (asset_town_*.webp)
#     │                      asset_town_elvengard.webp   엘븐가드 (720x350)
#     │                      asset_town_hendonmyre.webp  헨돈마이어 (720x342)
#     ├── mobile_apk_build_notes.md
#     └── __init__.py
#
# 주의: assets/font/ 안에는 폰트 파일(.ttf/.otf)만 둔다. 문서·노트
# 파일(mobile_apk_build_notes.md 등)은 에셋이 아니므로 여기 두지 않고
# game/ 바로 아래에 둔다.
#
# 폰트 관련 배경(한글 깨짐 문제 및 등록 코드)은
# mobile_apk_build_notes.md 참고.